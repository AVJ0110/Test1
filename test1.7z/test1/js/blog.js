// Sample blog posts data
const blogPosts = [
    {
        id: 1,
        title: "Mastering Technical Interviews",
        category: "interview",
        author: "Jane Smith",
        date: "March 14, 2024",
        readTime: "8 min read",
        excerpt: "Learn the best strategies for acing technical interviews, from coding challenges to system design questions.",
        image: "https://via.placeholder.com/400x300",
        tags: ["Interview", "Career", "Technical Skills"]
    },
    {
        id: 2,
        title: "The Rise of AI in Software Development",
        category: "tech",
        author: "Mike Johnson",
        date: "March 13, 2024",
        readTime: "6 min read",
        excerpt: "How artificial intelligence is transforming the way we write and maintain code.",
        image: "https://via.placeholder.com/400x300",
        tags: ["AI", "Technology", "Development"]
    },
    {
        id: 3,
        title: "Building a Strong Tech Portfolio",
        category: "career",
        author: "Sarah Williams",
        date: "March 12, 2024",
        readTime: "7 min read",
        excerpt: "Tips and tricks for creating a portfolio that stands out to tech recruiters.",
        image: "https://via.placeholder.com/400x300",
        tags: ["Portfolio", "Career", "Development"]
    },
    {
        id: 4,
        title: "Remote Work Best Practices",
        category: "industry",
        author: "David Brown",
        date: "March 11, 2024",
        readTime: "5 min read",
        excerpt: "How to maintain productivity and work-life balance in a remote tech job.",
        image: "https://via.placeholder.com/400x300",
        tags: ["Remote Work", "Productivity", "Work-Life Balance"]
    }
];

// Function to display blog posts
function displayBlogPosts(postsToShow = blogPosts) {
    const blogPostsContainer = document.getElementById('blogPosts');
    blogPostsContainer.innerHTML = '';

    postsToShow.forEach(post => {
        const postCard = document.createElement('div');
        postCard.className = 'blog-card';
        postCard.innerHTML = `
            <div class="blog-image">
                <img src="${post.image}" alt="${post.title}">
                <span class="category-tag">${post.category}</span>
            </div>
            <div class="blog-content">
                <h3>${post.title}</h3>
                <p class="article-meta">
                    <span><i class="fas fa-user"></i> ${post.author}</span>
                    <span><i class="fas fa-calendar"></i> ${post.date}</span>
                    <span><i class="fas fa-clock"></i> ${post.readTime}</span>
                </p>
                <p class="article-excerpt">${post.excerpt}</p>
                <div class="blog-tags">
                    ${post.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                </div>
                <a href="#" class="read-more">Read More</a>
            </div>
        `;
        blogPostsContainer.appendChild(postCard);
    });
}

// Function to search blog posts
function searchBlog() {
    const searchTerm = document.getElementById('blogSearch').value.toLowerCase();
    const category = document.getElementById('category').value;

    const filteredPosts = blogPosts.filter(post => {
        const matchesSearch = post.title.toLowerCase().includes(searchTerm) ||
                            post.excerpt.toLowerCase().includes(searchTerm) ||
                            post.tags.some(tag => tag.toLowerCase().includes(searchTerm));
        
        const matchesCategory = !category || post.category === category;

        return matchesSearch && matchesCategory;
    });

    displayBlogPosts(filteredPosts);
}

// Function to load more posts (simulated)
function loadMorePosts() {
    // In a real application, this would fetch more posts from a server
    alert('Loading more posts...');
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    displayBlogPosts();
}); 