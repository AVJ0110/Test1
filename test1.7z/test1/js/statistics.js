// Sample data for statistics
const statsData = {
    skills: {
        labels: ['JavaScript', 'Python', 'Java', 'React', 'Node.js', 'AWS'],
        data: [85, 78, 65, 72, 68, 60]
    },
    salary: {
        labels: ['Entry Level', 'Mid Level', 'Senior Level'],
        data: [
            [60000, 75000],
            [90000, 120000],
            [130000, 180000]
        ]
    },
    jobTypes: {
        labels: ['Full Time', 'Part Time', 'Contract', 'Remote'],
        data: [45, 15, 25, 15]
    },
    location: {
        labels: ['Remote', 'On-site', 'Hybrid'],
        data: [40, 35, 25]
    }
};

// Initialize charts when the page loads
document.addEventListener('DOMContentLoaded', () => {
    // Skills Chart
    new Chart(document.getElementById('skillsChart'), {
        type: 'bar',
        data: {
            labels: statsData.skills.labels,
            datasets: [{
                label: 'Demand Score',
                data: statsData.skills.data,
                backgroundColor: '#3498db',
                borderColor: '#2980b9',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });

    // Salary Chart
    new Chart(document.getElementById('salaryChart'), {
        type: 'bar',
        data: {
            labels: statsData.salary.labels,
            datasets: [{
                label: 'Salary Range',
                data: statsData.salary.data.map(range => range[0]),
                backgroundColor: '#2ecc71',
                borderColor: '#27ae60',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Salary ($)'
                    }
                }
            }
        }
    });

    // Job Types Chart
    new Chart(document.getElementById('jobTypesChart'), {
        type: 'pie',
        data: {
            labels: statsData.jobTypes.labels,
            datasets: [{
                data: statsData.jobTypes.data,
                backgroundColor: [
                    '#3498db',
                    '#e74c3c',
                    '#2ecc71',
                    '#f1c40f'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });

    // Location Chart
    new Chart(document.getElementById('locationChart'), {
        type: 'doughnut',
        data: {
            labels: statsData.location.labels,
            datasets: [{
                data: statsData.location.data,
                backgroundColor: [
                    '#3498db',
                    '#e74c3c',
                    '#2ecc71'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}); 