// Function to validate email format
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Function to validate form inputs
function validateForm(formData) {
    const errors = [];

    // Validate name
    if (formData.get('name').trim().length < 2) {
        errors.push('Name must be at least 2 characters long');
    }

    // Validate email
    if (!isValidEmail(formData.get('email'))) {
        errors.push('Please enter a valid email address');
    }

    // Validate subject
    if (!formData.get('subject')) {
        errors.push('Please select a subject');
    }

    // Validate message
    if (formData.get('message').trim().length < 10) {
        errors.push('Message must be at least 10 characters long');
    }

    return errors;
}

// Function to show form errors
function showErrors(errors) {
    const errorContainer = document.createElement('div');
    errorContainer.className = 'form-errors';
    errorContainer.innerHTML = `
        <h4>Please correct the following errors:</h4>
        <ul>
            ${errors.map(error => `<li>${error}</li>`).join('')}
        </ul>
    `;

    // Remove any existing error messages
    const existingErrors = document.querySelector('.form-errors');
    if (existingErrors) {
        existingErrors.remove();
    }

    // Insert new error messages before the form
    const form = document.getElementById('contactForm');
    form.parentNode.insertBefore(errorContainer, form);
}

// Function to show success message
function showSuccess() {
    const successMessage = document.createElement('div');
    successMessage.className = 'form-success';
    successMessage.innerHTML = `
        <h4>Thank you for your message!</h4>
        <p>We'll get back to you as soon as possible.</p>
    `;

    // Remove any existing messages
    const existingMessages = document.querySelector('.form-errors, .form-success');
    if (existingMessages) {
        existingMessages.remove();
    }

    // Insert success message before the form
    const form = document.getElementById('contactForm');
    form.parentNode.insertBefore(successMessage, form);

    // Reset the form
    form.reset();
}

// Function to handle form submission
function handleSubmit(event) {
    event.preventDefault();

    const form = event.target;
    const formData = new FormData(form);

    // Validate form data
    const errors = validateForm(formData);
    if (errors.length > 0) {
        showErrors(errors);
        return;
    }

    // In a real application, you would send the form data to a server here
    // For now, we'll just simulate a successful submission
    console.log('Form data:', Object.fromEntries(formData));
    showSuccess();
}

// Add event listener to the form
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('contactForm');
    if (form) {
        form.addEventListener('submit', handleSubmit);
    }
}); 