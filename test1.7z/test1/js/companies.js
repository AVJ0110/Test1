// Sample company data
const companies = [
    {
        id: 1,
        name: "TechCorp Inc.",
        industry: "software",
        location: "San Francisco, CA",
        description: "Leading software development company specializing in enterprise solutions.",
        openPositions: 15,
        logo: "https://via.placeholder.com/150",
        benefits: ["Health Insurance", "401k", "Remote Work", "Learning Budget"],
        techStack: ["React", "Node.js", "Python", "AWS"]
    },
    {
        id: 2,
        name: "AI Solutions",
        industry: "ai",
        location: "Boston, MA",
        description: "Pioneering AI research and implementation company.",
        openPositions: 8,
        logo: "https://via.placeholder.com/150",
        benefits: ["Health Insurance", "Stock Options", "Flexible Hours", "Conference Budget"],
        techStack: ["TensorFlow", "PyTorch", "Python", "CUDA"]
    },
    {
        id: 3,
        name: "CloudTech",
        industry: "cloud",
        location: "Seattle, WA",
        description: "Cloud infrastructure and DevOps solutions provider.",
        openPositions: 12,
        logo: "https://via.placeholder.com/150",
        benefits: ["Health Insurance", "Remote Work", "Gym Membership", "Training Budget"],
        techStack: ["AWS", "Kubernetes", "Docker", "Terraform"]
    },
    {
        id: 4,
        name: "SecureNet",
        industry: "cybersecurity",
        location: "Austin, TX",
        description: "Cybersecurity solutions for enterprise clients.",
        openPositions: 10,
        logo: "https://via.placeholder.com/150",
        benefits: ["Health Insurance", "401k", "Remote Work", "Security Training"],
        techStack: ["Python", "C++", "Linux", "Network Security"]
    }
];

// Function to display companies
function displayCompanies(companiesToShow = companies) {
    const companiesList = document.getElementById('companiesList');
    companiesList.innerHTML = '';

    companiesToShow.forEach(company => {
        const companyCard = document.createElement('div');
        companyCard.className = 'company-card';
        companyCard.innerHTML = `
            <div class="company-header">
                <img src="${company.logo}" alt="${company.name} logo" class="company-logo">
                <h3>${company.name}</h3>
            </div>
            <div class="company-info">
                <p><i class="fas fa-map-marker-alt"></i> ${company.location}</p>
                <p><i class="fas fa-briefcase"></i> ${company.openPositions} open positions</p>
                <p class="description">${company.description}</p>
                <div class="tech-stack">
                    <h4>Tech Stack:</h4>
                    <div class="tags">
                        ${company.techStack.map(tech => `<span class="tag">${tech}</span>`).join('')}
                    </div>
                </div>
                <div class="benefits">
                    <h4>Benefits:</h4>
                    <ul>
                        ${company.benefits.map(benefit => `<li><i class="fas fa-check"></i> ${benefit}</li>`).join('')}
                    </ul>
                </div>
                <button class="view-jobs-btn" onclick="viewCompanyJobs(${company.id})">View Jobs</button>
            </div>
        `;
        companiesList.appendChild(companyCard);
    });
}

// Function to search companies
function searchCompanies() {
    const searchTerm = document.getElementById('companySearch').value.toLowerCase();
    const industry = document.getElementById('industry').value;

    const filteredCompanies = companies.filter(company => {
        const matchesSearch = company.name.toLowerCase().includes(searchTerm) ||
                            company.description.toLowerCase().includes(searchTerm) ||
                            company.techStack.some(tech => tech.toLowerCase().includes(searchTerm));
        
        const matchesIndustry = !industry || company.industry === industry;

        return matchesSearch && matchesIndustry;
    });

    displayCompanies(filteredCompanies);
}

// Function to view company jobs
function viewCompanyJobs(companyId) {
    // This would typically redirect to a company-specific jobs page
    alert(`Viewing jobs for company ID: ${companyId}`);
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    displayCompanies();
}); 