// Sample events data
const events = [
    {
        id: 1,
        title: "Tech Innovation Summit 2024",
        type: "conference",
        date: "2024-06-15",
        endDate: "2024-06-17",
        location: "san-francisco",
        venue: "Moscone Center",
        description: "Join industry leaders and innovators for three days of networking, workshops, and keynote speeches about the future of technology.",
        image: "https://via.placeholder.com/600x400",
        attendees: 1000,
        price: "$499",
        speakers: ["John Smith", "Sarah Johnson", "Michael Chen"],
        tags: ["AI", "Cloud Computing", "Innovation"]
    },
    {
        id: 2,
        title: "Web Development Workshop",
        type: "workshop",
        date: "2024-05-20",
        endDate: "2024-05-20",
        location: "online",
        venue: "Virtual Event",
        description: "Learn modern web development techniques and best practices in this hands-on workshop.",
        image: "https://via.placeholder.com/600x400",
        attendees: 50,
        price: "$99",
        speakers: ["David Wilson"],
        tags: ["Web Development", "JavaScript", "React"]
    },
    {
        id: 3,
        title: "Tech Networking Mixer",
        type: "networking",
        date: "2024-05-25",
        endDate: "2024-05-25",
        location: "new-york",
        venue: "Tech Hub NYC",
        description: "Connect with fellow tech professionals and potential employers in a casual setting.",
        image: "https://via.placeholder.com/600x400",
        attendees: 200,
        price: "Free",
        speakers: [],
        tags: ["Networking", "Career Development"]
    },
    {
        id: 4,
        title: "AI Hackathon 2024",
        type: "hackathon",
        date: "2024-07-10",
        endDate: "2024-07-12",
        location: "london",
        venue: "Tech Campus London",
        description: "Build innovative AI solutions and compete for prizes in this 48-hour hackathon.",
        image: "https://via.placeholder.com/600x400",
        attendees: 150,
        price: "$149",
        speakers: ["Emma Thompson", "James Wilson"],
        tags: ["AI", "Machine Learning", "Hackathon"]
    }
];

// Function to format date
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
}

// Function to display events
function displayEvents(eventsToShow = events) {
    const eventsContainer = document.getElementById('eventsList');
    eventsContainer.innerHTML = '';

    eventsToShow.forEach(event => {
        const eventCard = document.createElement('div');
        eventCard.className = 'event-card';
        eventCard.innerHTML = `
            <div class="event-image">
                <img src="${event.image}" alt="${event.title}">
                <span class="event-tag">${event.type}</span>
            </div>
            <div class="event-content">
                <h3>${event.title}</h3>
                <p class="event-meta">
                    <span><i class="fas fa-calendar"></i> ${formatDate(event.date)}</span>
                    <span><i class="fas fa-map-marker-alt"></i> ${event.venue}</span>
                    <span><i class="fas fa-users"></i> ${event.attendees} Attendees</span>
                </p>
                <p class="event-description">${event.description}</p>
                <div class="event-tags">
                    ${event.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                </div>
                <div class="event-footer">
                    <span class="event-price">${event.price}</span>
                    <button class="register-btn" onclick="registerEvent(${event.id})">Register</button>
                </div>
            </div>
        `;
        eventsContainer.appendChild(eventCard);
    });
}

// Function to search events
function searchEvents() {
    const searchTerm = document.getElementById('eventSearch').value.toLowerCase();
    const eventType = document.getElementById('eventType').value;
    const location = document.getElementById('location').value;

    const filteredEvents = events.filter(event => {
        const matchesSearch = event.title.toLowerCase().includes(searchTerm) ||
                            event.description.toLowerCase().includes(searchTerm) ||
                            event.tags.some(tag => tag.toLowerCase().includes(searchTerm));
        
        const matchesType = !eventType || event.type === eventType;
        const matchesLocation = !location || event.location === location;

        return matchesSearch && matchesType && matchesLocation;
    });

    displayEvents(filteredEvents);
}

// Function to register for an event
function registerEvent(eventId) {
    // In a real application, this would handle the registration process
    alert(`Registration for event ${eventId} would be processed here.`);
}

// Function to generate calendar
function generateCalendar() {
    const calendarGrid = document.getElementById('calendarGrid');
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();

    // Get events for the current month
    const monthEvents = events.filter(event => {
        const eventDate = new Date(event.date);
        return eventDate.getMonth() === currentMonth && eventDate.getFullYear() === currentYear;
    });

    // Create calendar HTML
    let calendarHTML = `
        <div class="calendar-header">
            <h4>${currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}</h4>
        </div>
        <div class="calendar-days">
            ${['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => `<div class="calendar-day-header">${day}</div>`).join('')}
        </div>
        <div class="calendar-dates">
    `;

    // Add dates and events
    const firstDay = new Date(currentYear, currentMonth, 1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    
    for (let i = 0; i < firstDay.getDay(); i++) {
        calendarHTML += '<div class="calendar-date empty"></div>';
    }

    for (let date = 1; date <= lastDay.getDate(); date++) {
        const dayEvents = monthEvents.filter(event => new Date(event.date).getDate() === date);
        calendarHTML += `
            <div class="calendar-date ${dayEvents.length > 0 ? 'has-events' : ''}">
                <span class="date-number">${date}</span>
                ${dayEvents.map(event => `
                    <div class="calendar-event" onclick="showEventDetails(${event.id})">
                        ${event.title}
                    </div>
                `).join('')}
            </div>
        `;
    }

    calendarHTML += '</div>';
    calendarGrid.innerHTML = calendarHTML;
}

// Function to show event details
function showEventDetails(eventId) {
    const event = events.find(e => e.id === eventId);
    if (event) {
        alert(`Event Details:\n${event.title}\n${formatDate(event.date)}\n${event.venue}`);
    }
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    displayEvents();
    generateCalendar();
}); 