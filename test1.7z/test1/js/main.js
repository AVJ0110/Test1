// Sample job data
const jobs = [
    {
        id: 1,
        title: "Senior Frontend Developer",
        company: "TechCorp Inc.",
        location: "San Francisco, CA",
        type: "full-time",
        experience: "senior",
        skills: ["React", "TypeScript", "Node.js"],
        salary: "$120k - $150k",
        description: "Looking for an experienced frontend developer to join our team..."
    },
    {
        id: 2,
        title: "Backend Developer",
        company: "DataSystems",
        location: "Remote",
        type: "full-time",
        experience: "mid",
        skills: ["Python", "Django", "PostgreSQL"],
        salary: "$90k - $110k",
        description: "Join our backend team to build scalable applications..."
    },
    {
        id: 3,
        title: "Full Stack Developer",
        company: "StartupX",
        location: "New York, NY",
        type: "contract",
        experience: "mid",
        skills: ["JavaScript", "React", "Node.js", "MongoDB"],
        salary: "$100k - $130k",
        description: "Full stack developer needed for exciting startup project..."
    },
    {
        id: 4,
        title: "DevOps Engineer",
        company: "CloudTech",
        location: "Remote",
        type: "full-time",
        experience: "senior",
        skills: ["AWS", "Docker", "Kubernetes"],
        salary: "$130k - $160k",
        description: "DevOps engineer to manage our cloud infrastructure..."
    },
    {
        id: 5,
        title: "Junior Frontend Developer",
        company: "WebSolutions",
        location: "Chicago, IL",
        type: "full-time",
        experience: "entry",
        skills: ["HTML", "CSS", "JavaScript"],
        salary: "$60k - $75k",
        description: "Entry-level frontend developer position..."
    }
];

// Function to display jobs
function displayJobs(jobsToShow = jobs) {
    const jobsList = document.getElementById('jobsList');
    jobsList.innerHTML = '';

    jobsToShow.forEach(job => {
        const jobCard = document.createElement('div');
        jobCard.className = 'job-card';
        jobCard.innerHTML = `
            <h4>${job.title}</h4>
            <div class="company">${job.company} - ${job.location}</div>
            <div class="salary">${job.salary}</div>
            <div class="tags">
                ${job.skills.map(skill => `<span class="tag">${skill}</span>`).join('')}
            </div>
            <p>${job.description}</p>
        `;
        jobsList.appendChild(jobCard);
    });
}

// Function to search jobs
function searchJobs() {
    const searchTerm = document.getElementById('jobSearch').value.toLowerCase();
    const jobType = document.getElementById('jobType').value;
    const experience = document.getElementById('experience').value;

    const filteredJobs = jobs.filter(job => {
        const matchesSearch = job.title.toLowerCase().includes(searchTerm) ||
                            job.company.toLowerCase().includes(searchTerm) ||
                            job.skills.some(skill => skill.toLowerCase().includes(searchTerm));
        
        const matchesType = !jobType || job.type === jobType;
        const matchesExperience = !experience || job.experience === experience;

        return matchesSearch && matchesType && matchesExperience;
    });

    displayJobs(filteredJobs);
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    displayJobs();
}); 