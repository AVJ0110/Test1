// Sample posts data
const posts = [
    {
        id: 1,
        title: "Tips for Acing Technical Interviews",
        category: "interview",
        author: {
            name: "Sarah Johnson",
            avatar: "https://via.placeholder.com/50",
            role: "Senior Software Engineer",
            company: "TechCorp"
        },
        content: "Here are my top tips for technical interviews based on my experience as both an interviewer and interviewee...",
        date: "2024-03-15",
        likes: 245,
        comments: 32,
        tags: ["Interview", "Career", "Technical Skills"]
    },
    {
        id: 2,
        title: "The Future of AI in Software Development",
        category: "tech",
        author: {
            name: "Michael Chen",
            avatar: "https://via.placeholder.com/50",
            role: "AI Researcher",
            company: "AI Solutions"
        },
        content: "With the rapid advancement of AI tools, how do you think they will impact software development in the next 5 years?",
        date: "2024-03-14",
        likes: 189,
        comments: 45,
        tags: ["AI", "Technology", "Future"]
    },
    {
        id: 3,
        title: "Building a Strong Tech Portfolio",
        category: "career",
        author: {
            name: "David Wilson",
            avatar: "https://via.placeholder.com/50",
            role: "Full Stack Developer",
            company: "WebTech"
        },
        content: "What projects should you include in your portfolio to stand out to tech recruiters?",
        date: "2024-03-13",
        likes: 156,
        comments: 28,
        tags: ["Portfolio", "Career", "Projects"]
    }
];

// Sample contributors data
const contributors = [
    {
        name: "Sarah Johnson",
        avatar: "https://via.placeholder.com/50",
        role: "Senior Software Engineer",
        company: "TechCorp",
        posts: 156,
        solutions: 89
    },
    {
        name: "Michael Chen",
        avatar: "https://via.placeholder.com/50",
        role: "AI Researcher",
        company: "AI Solutions",
        posts: 142,
        solutions: 76
    },
    {
        name: "David Wilson",
        avatar: "https://via.placeholder.com/50",
        role: "Full Stack Developer",
        company: "WebTech",
        posts: 98,
        solutions: 45
    }
];

// Sample tags data
const tags = [
    { name: "Career", count: 245 },
    { name: "Interview", count: 189 },
    { name: "AI", count: 156 },
    { name: "Web Development", count: 142 },
    { name: "Cloud", count: 98 },
    { name: "Security", count: 87 },
    { name: "Mobile", count: 76 },
    { name: "DevOps", count: 65 }
];

// Function to format date
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
}

// Function to display posts
function displayPosts(postsToShow = posts) {
    const postsContainer = document.getElementById('postsList');
    postsContainer.innerHTML = '';

    postsToShow.forEach(post => {
        const postElement = document.createElement('div');
        postElement.className = 'post-card';
        postElement.innerHTML = `
            <div class="post-header">
                <div class="author-info">
                    <img src="${post.author.avatar}" alt="${post.author.name}" class="author-avatar">
                    <div class="author-details">
                        <h4>${post.author.name}</h4>
                        <p>${post.author.role} at ${post.author.company}</p>
                    </div>
                </div>
                <span class="post-date">${formatDate(post.date)}</span>
            </div>
            <div class="post-content">
                <h3>${post.title}</h3>
                <p>${post.content}</p>
                <div class="post-tags">
                    ${post.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                </div>
            </div>
            <div class="post-footer">
                <div class="post-stats">
                    <span><i class="fas fa-heart"></i> ${post.likes}</span>
                    <span><i class="fas fa-comment"></i> ${post.comments}</span>
                </div>
                <button class="view-discussion-btn" onclick="viewDiscussion(${post.id})">View Discussion</button>
            </div>
        `;
        postsContainer.appendChild(postElement);
    });
}

// Function to display top contributors
function displayContributors() {
    const contributorsContainer = document.getElementById('topContributors');
    contributorsContainer.innerHTML = '';

    contributors.forEach(contributor => {
        const contributorElement = document.createElement('div');
        contributorElement.className = 'contributor-card';
        contributorElement.innerHTML = `
            <img src="${contributor.avatar}" alt="${contributor.name}" class="contributor-avatar">
            <div class="contributor-info">
                <h4>${contributor.name}</h4>
                <p>${contributor.role}</p>
                <p class="company">${contributor.company}</p>
                <div class="contributor-stats">
                    <span>${contributor.posts} Posts</span>
                    <span>${contributor.solutions} Solutions</span>
                </div>
            </div>
        `;
        contributorsContainer.appendChild(contributorElement);
    });
}

// Function to display tags cloud
function displayTagsCloud() {
    const tagsContainer = document.getElementById('tagsCloud');
    tagsContainer.innerHTML = '';

    tags.forEach(tag => {
        const tagElement = document.createElement('span');
        tagElement.className = 'tag-cloud-item';
        tagElement.style.fontSize = `${Math.max(0.8, Math.min(1.5, tag.count / 100))}rem`;
        tagElement.innerHTML = `
            ${tag.name}
            <span class="tag-count">${tag.count}</span>
        `;
        tagsContainer.appendChild(tagElement);
    });
}

// Function to search posts
function searchPosts() {
    const searchTerm = document.getElementById('postSearch').value.toLowerCase();
    const category = document.getElementById('category').value;
    const sortBy = document.getElementById('sortBy').value;

    let filteredPosts = posts.filter(post => {
        const matchesSearch = post.title.toLowerCase().includes(searchTerm) ||
                            post.content.toLowerCase().includes(searchTerm) ||
                            post.tags.some(tag => tag.toLowerCase().includes(searchTerm));
        
        const matchesCategory = !category || post.category === category;

        return matchesSearch && matchesCategory;
    });

    // Sort posts
    switch (sortBy) {
        case 'popular':
            filteredPosts.sort((a, b) => b.likes - a.likes);
            break;
        case 'comments':
            filteredPosts.sort((a, b) => b.comments - a.comments);
            break;
        default: // recent
            filteredPosts.sort((a, b) => new Date(b.date) - new Date(a.date));
    }

    displayPosts(filteredPosts);
}

// Function to show new post form
function showNewPostForm() {
    // In a real application, this would show a modal or form for creating a new post
    alert('New post form would be displayed here.');
}

// Function to view discussion
function viewDiscussion(postId) {
    // In a real application, this would navigate to the full discussion page
    alert(`Viewing discussion for post ${postId}`);
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    displayPosts();
    displayContributors();
    displayTagsCloud();
}); 